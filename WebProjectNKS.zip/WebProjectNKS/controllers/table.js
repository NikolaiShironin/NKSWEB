const db = require("../routes/db-config")
const table = (req, res, next) => {
      db.query("SELECT * FROM services", function(err, data) {
      if(err) return console.log(err);
      res.render({ services:data
    });
  });
}
module.exports = table;