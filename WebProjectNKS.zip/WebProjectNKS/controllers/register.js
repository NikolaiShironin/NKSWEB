const db = require("../routes/db-config");
const bcrypt = require("bcryptjs");

const register = async (req, res) => {
    const { Surname, Forename, Adress, PhoneNumber, Email, Password: Npassword, idRole } = req.body
    if (!Surname || !Forename || !Adress || !PhoneNumber || !Email || !Npassword || idRole) return res.json({ status:"error", error:"Please Enter your email and passsword" });
    else {
        db.query('SELECT Email FROM users WHERE Email = ?', [Email], async (err, result) =>{
            if (err) throw err;
            if (result[0]) return res.json({ status:"error", error:"Электронная почта уже зарегистрирована" })
            else {
                const Password = await bcrypt.hash(Npassword, 8);
                db.query('INSERT INTO users SET ?', { Surname:Surname, Forename: Forename, Adress: Adress, PhoneNumber: PhoneNumber, Email: Email, Password: Password, idRole: 1 }, (error, results) => {
                    if(error) throw error;
                    return res.json({ status:"success", success: "Регистрация прошла успешно" })
                })
            }
        })
    }
}
module.exports = register;