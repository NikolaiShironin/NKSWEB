const db = require("../routes/db-config");
const bcrypt = require("bcryptjs");

const registeradmin = async (req, res) => {
    const { Surname, Forename, PhoneNumber, Email, Password: Npassword, idRole } = req.body
    if (!Surname || !Forename || !PhoneNumber || !Email || !Npassword || idRole) return res.json({ status:"error", error:"Please Enter your email and passsword" });
    else {
        db.query('SELECT Email FROM users WHERE Email = ?', [Email], async (err, result) =>{
            if (err) throw err;
            if (result[0]) return res.json({ status:"error", error:"Электронная почта уже зарегистрирована" })
            else {
                const Password = await bcrypt.hash(Npassword, 8);
                db.query('INSERT INTO users SET ?', { Surname:Surname, Forename: Forename, PhoneNumber: PhoneNumber, Email: Email, Password: Password, idRole: 2 }, (error, results) => {
                    if(error) throw error;
                    return res.json({ status:"success", success: "Регистрация администратора прошла успешно" })
                })
            }
        })
    }
}
module.exports = registeradmin;