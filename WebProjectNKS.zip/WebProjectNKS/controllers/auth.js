const express = require("express");
const register = require("./register")
const registeradmin = require("./registeradmin")
const login = require("./login")
const router = express.Router();

router.post("/register", register)
router.post("/registeradmin", registeradmin)
router.post("/login", login)

module.exports = router;