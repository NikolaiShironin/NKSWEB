const button = document.getElementById('ButtonProfitExcel');
button.addEventListener('click', function(e) {
  console.log('button was clicked');
});