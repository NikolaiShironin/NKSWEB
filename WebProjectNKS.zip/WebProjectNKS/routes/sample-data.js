/*var express = require('express');
var router = express.Router();
var db = require("../routes/db-config")
router.get("/", function(req, res, next){
    res.render('index', {title : 'Node JS Ajax CRUD Application'})
});
router.post("/action", function(req, res, next){
    var action = req.body.action;
    if(action == 'fetch')
    {
        var query = "SELECT * FROM services";
        db.query(query, function(err, data){
            res.json({
                data:data
            });
        });
    }
});
*/