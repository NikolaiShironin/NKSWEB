const express = require("express");
const loggedin = require("../controllers/loggedin")
const logout = require("../controllers/logout");
const urlencodedParser = express.urlencoded({extended: false});
const db = require("./db-config");
const router = express.Router();
const excelJs = require("exceljs");
var fs = require('fs');

router.get("/export", async (req,res)=>{
  try{
    const [rows, fields] = await db.query("select * from services")
    
    const heading = [['idServices', 'ServiceName']]
    const workbook = XLSX.utils.book_new()
    const worksheet = XLSX.utils.json_to_sheet(rows)
    XLSX.utils.sheet_add_aoa(worksheet, heading)
    XLSX.utils.book_append_sheet(workbook, worksheet, 'books')

    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer'})

    res.attachment('data.xlsx')
    return res.send(buffer)

  } catch (error) {
    console.log(error)
  }
})

router.get("/", loggedin, (req, res) => {
    if(req.user) {
        res.render("index", {status: "loggedin", user: req.user});
    } else {
        res.render("index", {status: "no", user: "nothing"});
    }
})
router.get("/", function(req, res){
    db.query("SELECT * FROM services", function(err, data) {
      if(err) return console.log(err);
      res.render("index", {
        services: data
      });
    });
});
router.get("/register", (req, res) => {
    res.sendFile("register.html", { root: "./public" });
})
router.get("/registeradmin", (req, res) => {
  res.sendFile("registeradmin.html", { root: "./public" });
})
router.get("/login", (req, res) => {
    res.sendFile("login.html", { root: "./public/" });
})
router.get("/profile", loggedin, (req, res) => {
    res.sendFile("profile.html", { root: "./public/" });
})
router.get("/logout", logout)
module.exports = router;

router.get("/services", function(req, res){
    db.query("SELECT * FROM services", function(err, data) {
      if(err) return console.log(err);
      res.render("services.hbs", {
        services: data
      });
    });
});

router.get("/appeals", loggedin, function(req, res){
  const idUsers = req.user.idUsers;
    db.query('SELECT appeals.idAppeals, DateCreate, services.ServiceName, services.ServiceType, services.Unit, services.Price, Quantity, idStatus, services.Price * Quantity count FROM appeals JOIN services ON appeals.idServices = services.idServices Where idUsers = ? AND idStatus = 1 ORDER BY idAppeals', [idUsers], function(err, data) {
      if(err) return console.log(err);
      res.render("appeals.hbs", {
        appealsActive: data
      });
    });
});

router.get("/historyappeals", loggedin, function(req, res){
  const idUsers = req.user.idUsers;
    db.query('SELECT appeals.idAppeals, appeals.DateCreate, appeals.DateComplete, services.ServiceName, services.ServiceType, services.Unit, services.Price, appeals.Quantity, services.Price * appeals.Quantity count, statusap.NameStatus FROM appeals JOIN services ON appeals.idServices = services.idServices JOIN statusap ON appeals.idStatus = statusap.idStatus Where idUsers = ? AND appeals.idStatus in (2,3,4) ORDER BY statusap.idStatus in (2,3,4)', [idUsers], function(err, data) {
      if(err) return console.log(err);
      res.render("historyappeals.hbs", {
        appealsHis: data
      });
    });
});

router.get("/servicesonapp", function(req, res){
  db.query("SELECT * FROM services", function(err, data) {
    if(err) return console.log(err);
    res.render("servicesonapp.hbs", {
      services: data
    });
  });
});

router.get("/clients", function(req, res){
  db.query("SELECT * FROM users where idRole = 1", function(err, data) {
    if(err) return console.log(err);
    res.render("clients.hbs", {
      clientslist: data
    });
  });
});

router.get("/cancel", function(req, res){
  db.query("SELECT * FROM users where idRole = 1", function(err, data) {
    if(err) return console.log(err);
    res.render("cancel.hbs", {
      cancellist: data
    });
  });
});

router.get("/clientappeals/:idUsers", function(req, res){
  const idUsers = req.params.idUsers;
  db.query("SELECT appeals.idAppeals, appeals.DateCreate, appeals.DateComplete, services.ServiceName, services.ServiceType, services.Unit, services.Price, appeals.Quantity, services.Price * appeals.Quantity count, statusap.NameStatus FROM appeals JOIN services ON appeals.idServices = services.idServices JOIN statusap ON appeals.idStatus = statusap.idStatus Where idUsers = ? AND appeals.idStatus in (1) ORDER BY statusap.idStatus in (1)", [idUsers], function(err, data) {
    if(err) return console.log(err);
     res.render("clientappeals.hbs", {
      clientappealslist: data
    });
  });
});

router.get("/createappeals", function(req, res){
    res.render("createappeals.hbs");
});

router.get("/createappeals/:idServices", function(req, res){
  const idServices = req.params.idServices;
  db.query("SELECT * FROM services WHERE idServices=?", [idServices], function(err, data) {
    if(err) return console.log(err);
     res.render("createappeals.hbs", {
      Service: data[0]
    });
  });
});

router.post("/createappeals", urlencodedParser, loggedin, function (req, res) {
         
    if(!req.body) return res.sendStatus(400);
    const idUsers = req.user.idUsers;
    const idServices = req.body.idServices;
    const Quantity = req.body.Quantity;
    var today = new Date();
    const DateCreate = today;

    db.query("INSERT INTO appeals (idUsers, idServices, Quantity, DateCreate) VALUES (?,?,?,?)", [idUsers, idServices, Quantity, DateCreate], function(err, data) {
      if(err) return console.log(err);
      res.redirect("/appeals");
    });
});

router.get("/cancelappeals/:idAppeals", function(req, res){
  const idAppeals = req.params.idAppeals;
  db.query("SELECT * FROM appeals WHERE idAppeals=?", [idAppeals], function(err, data) {
    if(err) return console.log(err);
     res.render("cancelappeals.hbs", {
      appeals: data[0]
    });
  });
});

router.post("/cancelappeals", urlencodedParser, function (req, res) {
         
  if(!req.body) return res.sendStatus(400);
  const idAppeals = req.body.idAppeals;

  db.query("UPDATE appeals SET idStatus = 3 Where idAppeals = ?", [idAppeals], function(err, data) {
    if(err) return console.log(err);
    res.redirect("/appeals");
  });
});

router.get("/finappeals/:idAppeals", function(req, res){
  const idAppeals = req.params.idAppeals;
  db.query("SELECT * FROM appeals WHERE idAppeals=?", [idAppeals], function(err, data) {
    if(err) return console.log(err);
     res.render("finappeals.hbs", {
      appeals: data[0]
    });
  });
});

router.post("/finappeals", urlencodedParser, function (req, res) {
         
  if(!req.body) return res.sendStatus(400);
  const idAppeals = req.body.idAppeals;
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
  var yyyy = today.getFullYear();
  var hh = today.getHours()
  var m = today.getMinutes()
  var s = today.getSeconds()
  today = yyyy + '-' + mm + '-' + dd + ' ' + hh + ':' + m + ':' + s;

  db.query(`UPDATE appeals SET DateComplete = '${today}', idStatus = 2 Where idAppeals = ${idAppeals}`, function(err, data) {
    if(err) return console.log(err);
    res.redirect("/clients");
  });
});

router.get("/cancelclientappeals/:idUsers", function(req, res){
  const idUsers = req.params.idUsers;
  db.query("SELECT appeals.idAppeals, appeals.DateCreate, appeals.DateComplete, services.ServiceName, services.ServiceType, services.Unit, services.Price, appeals.Quantity, services.Price * appeals.Quantity count, statusap.NameStatus FROM appeals JOIN services ON appeals.idServices = services.idServices JOIN statusap ON appeals.idStatus = statusap.idStatus Where idUsers = ? AND appeals.idStatus in (3) ORDER BY statusap.idStatus in (3)", [idUsers], function(err, data) {
    if(err) return console.log(err);
     res.render("cancelclientappeals.hbs", {
      cancellist: data
    });
  });
});

router.get("/cancelapp/:idAppeals", function(req, res){
  const idAppeals = req.params.idAppeals;
  db.query("SELECT * FROM appeals WHERE idAppeals=?", [idAppeals], function(err, data) {
    if(err) return console.log(err);
     res.render("cancelapp.hbs", {
      appeals: data[0]
    });
  });
});

router.post("/cancelapp", urlencodedParser, function (req, res) {
         
  if(!req.body) return res.sendStatus(400);
  const idAppeals = req.body.idAppeals;

  db.query(`UPDATE appeals SET idStatus = 4 Where idAppeals = ${idAppeals}`, function(err, data) {
    if(err) return console.log(err);
    res.redirect("/cancel");
  });
});

router.get("/backapp/:idAppeals", function(req, res){
  const idAppeals = req.params.idAppeals;
  db.query("SELECT * FROM appeals WHERE idAppeals=?", [idAppeals], function(err, data) {
    if(err) return console.log(err);
     res.render("backapp.hbs", {
      appeals: data[0]
    });
  });
});

router.post("/backapp", urlencodedParser, function (req, res) {
         
  if(!req.body) return res.sendStatus(400);
  const idAppeals = req.body.idAppeals;

  db.query(`UPDATE appeals SET idStatus = 1 Where idAppeals = ${idAppeals}`, function(err, data) {
    if(err) return console.log(err);
    res.redirect("/cancel");
  });
});